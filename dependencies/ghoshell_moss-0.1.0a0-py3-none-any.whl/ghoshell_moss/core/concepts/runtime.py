import contextlib

import asyncio
from abc import ABC, abstractmethod
from typing import Optional, Iterable, Any, TypeVar, Generic, Callable

from ghoshell_container import IoCContainer, Container

from ghoshell_moss.core.concepts.command import (
    CommandTask,
    CommandStackResult,
    CommandUniqueName,
    Command,
    CommandTaskState,
)
from ghoshell_moss.core.concepts.states import StateStore, BaseStateStore, State
from ghoshell_moss.core.concepts.topic import TopicService
from ghoshell_moss.core.concepts.channel import (
    ChannelCtx,
    Channel,
    ChannelMeta,
    TaskDoneCallback,
    ChannelRuntime,
    ChannelFullPath,
    ChannelPaths,
    ChannelImportLib,
)
from ghoshell_moss.core.concepts.errors import CommandErrorCode
from ghoshell_moss.core.helpers import ThreadSafeEvent
from ghoshell_common.contracts import LoggerItf
import logging
import time

__all__ = ["AbsChannelRuntime", "BaseImportLib", "AbsChannelTreeRuntime"]

_ChannelId = str


class BaseImportLib(ChannelImportLib):
    """
    唯一的 lib 用来管理所有可以被 import 的 channel runtime
    """

    def __init__(self, main: ChannelRuntime, container: IoCContainer | None = None):
        self._main = main
        self._name = "MossChannelImportLib/{}/{}".format(main.name, main.id)
        self._container = Container(
            name=self._name,
            parent=container,
        )
        # 绑定自身到容器中. 凡是用这个容器启动的 runtime, 都可以拿到 ChannelImportLib 并获取子 channel runtime.
        self._container.set(BaseImportLib, self)
        self._logger: Optional[LoggerItf] = None
        self._runtimes: dict[_ChannelId, ChannelRuntime] = {}
        self._runtimes_lock: asyncio.Lock = asyncio.Lock()
        self._topics: TopicService | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._async_exit_stack = contextlib.AsyncExitStack()
        self._start: bool = False
        self._close: bool = False

    def get_channel_runtime(self, channel: Channel) -> ChannelRuntime | None:
        if channel is self._main.channel:
            # 根节点不启动.
            return self._main

        if not self.is_running():
            return None

        channel_id = channel.id()
        return self._runtimes.get(channel_id)

    async def get_or_create_channel_runtime(self, channel: Channel) -> ChannelRuntime | None:
        if runtime := self.get_channel_runtime(channel):
            await runtime.wait_started()
            if runtime.is_running():
                return runtime
            else:
                return None
        # 第一次创建.
        runtime = await self.compile_channel(channel)
        if runtime is None:
            return None
        await runtime.wait_started()
        return runtime

    async def compile_channel(self, channel: Channel) -> ChannelRuntime | None:
        # 只有创建这一段需要上锁.
        if not self.is_running():
            return None
        channel_id = channel.id()
        runtime = self._runtimes.get(channel_id)
        # 只要 runtime 存在就立刻返回.
        if runtime is not None:
            return runtime
        await self._runtimes_lock.acquire()
        try:
            # 用自身的容器启动 ChannelImportLib.
            runtime = channel.bootstrap(self._container)
            # 避免抢锁嵌套成环.
            self._runtimes[channel_id] = runtime
            _ = asyncio.create_task(runtime.start())
            return runtime
        except Exception as e:
            self.logger.exception(
                "%s failed to build channel %s, id=%s: %s", self._name, channel.name(), channel.id(), e
            )
            return None
        finally:
            self._runtimes_lock.release()

    @property
    def main(self) -> ChannelRuntime:
        return self._main

    @property
    def topics(self) -> TopicService:
        if not self.is_running():
            raise RuntimeError("Not running")
        return self._topics

    @property
    def logger(self):
        if self._logger is None:
            self._logger = self._container.get(LoggerItf)
            if self._logger is None:
                logger = logging.getLogger("moss")
                self._logger = logger
                self._container.set(LoggerItf, logger)
        return self._logger

    def is_running(self) -> bool:
        return self._start and not self._close

    @contextlib.asynccontextmanager
    async def _container_ctx_manager(self):
        await asyncio.to_thread(self._container.bootstrap)
        yield
        await asyncio.to_thread(self._container.shutdown)

    @contextlib.asynccontextmanager
    async def _topics_ctx_manager(self):
        self._topics = self._container.get(TopicService)
        if not self._topics:
            self._topics = self._create_default_topics()
            self._container.set(TopicService, self._topics)
        topic_started = False
        if not self._topics.is_running():
            await self._topics.start()
            topic_started = True
        yield
        if topic_started:
            await self._topics.close()

    async def start(self) -> None:
        if self._start:
            return
        self._start = True
        self._loop = asyncio.get_event_loop()
        await self._async_exit_stack.__aenter__()
        await self._async_exit_stack.enter_async_context(self._container_ctx_manager())
        await self._async_exit_stack.enter_async_context(self._topics_ctx_manager())

    def _create_default_topics(self) -> TopicService:
        from ghoshell_moss.core.topic import QueueBasedTopicService

        return QueueBasedTopicService(sender=self.main.id)

    async def close(self) -> None:
        if self._close:
            return
        self._close = True
        # todo: 实现更可靠的生命周期.
        await self._runtimes_lock.acquire()
        try:
            clear_runtimes = []
            clear_runtime_tasks = []
            closing_runtime_ids = set()
            for runtime in self._runtimes.values():
                if runtime.is_running():
                    if runtime.id in closing_runtime_ids:
                        continue
                    closing_runtime_ids.add(runtime.id)
                    clear_task = self._loop.create_task(runtime.close())
                    clear_runtimes.append(runtime)
                    clear_runtime_tasks.append(clear_task)
            done = await asyncio.gather(*clear_runtime_tasks, return_exceptions=True)
            idx = 0
            self._runtimes.clear()
            for t in done:
                if isinstance(t, Exception):
                    runtime = clear_runtimes[idx]
                    self.logger.exception(
                        "%s close runtime %s, id=%s failed: %s", self._name, runtime.name, runtime.id, t
                    )
                idx += 1
        finally:
            self._runtimes_lock.release()
            await self._async_exit_stack.__aexit__(None, None, None)
            if self._loop:
                self._loop.run_in_executor(None, self._container.shutdown)


CHANNEL = TypeVar("CHANNEL", bound=Channel)


class AbsChannelRuntime(Generic[CHANNEL], ChannelRuntime, ABC):
    """
    实现基础的 Channel Runtime, 用来给所有的 Runtime 提供基准的生命周期.
    """

    def __init__(
        self,
        *,
        channel: CHANNEL,
        container: IoCContainer | None = None,
        logger: LoggerItf | None = None,
        state_store: StateStore | None = None,
    ):
        self._channel: CHANNEL = channel
        self._name = channel.name()
        self._uid = channel.id()
        # 用不同的容器隔离依赖. 经过 prepare container 才进行封装.
        container = Container(
            name=f"MossChannelRuntime/{self._name}/{self._uid}",
            parent=container,
        )
        self._container: IoCContainer = container
        self._logger: LoggerItf | None = logger
        self._state_store: StateStore | None = state_store
        # import lib 是最重要的.
        self._importlib: BaseImportLib | None = None

        self._logger: LoggerItf | None = logger

        self._starting = False
        self._started = asyncio.Event()
        self._running_task: Optional[asyncio.Task] = None
        # 用线程安全的事件. 考虑到 runtime 未来可能会跨线程被使用.
        self._closing_event = ThreadSafeEvent()
        self._closed_event = ThreadSafeEvent()

        self._own_metas_cache: dict[ChannelFullPath, ChannelMeta] = {}
        # 可以注册监听, 监听 refresh meta 动作.
        self._refresh_meta_lock = asyncio.Lock()

        self._defer_clear_mark = False
        self._loop: asyncio.AbstractEventLoop | None = None
        self._main_loop_task: Optional[asyncio.Task] = None
        self._task_done_callbacks: list[TaskDoneCallback] = []
        self._exit_stack = contextlib.AsyncExitStack()
        # log_prefix
        self.log_prefix = "[Channel `%s`][%s][%s] " % (self._name, self.__class__.__name__, self._uid)

    @property
    def channel(self) -> CHANNEL:
        return self._channel

    @property
    def states(self) -> StateStore:
        """
        返回当前 Channel 的状态存储.
        """
        if self._state_store is None:
            # 必须依赖一个 state store.
            self._state_store = self._container.force_fetch(StateStore)
        return self._state_store

    @property
    def logger(self) -> LoggerItf:
        if self._logger is None:
            # 日志总要有吧.
            self._logger = self._container.get(LoggerItf) or logging.getLogger("moss")
        return self._logger

    @property
    def importlib(self) -> BaseImportLib:
        if not self._importlib:
            raise RuntimeError(f"channel is not running")
        return self._importlib

    @property
    def container(self) -> IoCContainer:
        """
        runtime 所持有的 ioc 容器.
        """
        return self._container

    def prepare_container(self, container: IoCContainer) -> IoCContainer:
        # 重写这个函数完成自定义.
        return container

    async def fetch_sub_runtime(self, path: ChannelFullPath) -> ChannelRuntime | None:
        paths = Channel.split_channel_path_to_names(path)
        return await self.importlib.recursively_fetch_runtime(self, paths)

    @property
    def id(self) -> str:
        """
        runtime 的唯一 id.
        """
        return self._uid

    @property
    def name(self) -> str:
        """
        对应的 channel name.
        """
        return self._name

    # --- abstract -- #

    @abstractmethod
    async def on_start_up(self) -> None:
        pass

    # --- interface --- #

    def own_metas(self) -> dict[ChannelFullPath, ChannelMeta]:
        return self._own_metas_cache

    def metas(self) -> dict[ChannelFullPath, ChannelMeta]:
        """
        返回 Channel 自身的 Meta.
        """
        if not self.is_running() or not self.is_connected():
            return {"": ChannelMeta.new_empty(self._uid, self.channel)}
        own_metas = self.own_metas()
        # 还是复制一份.
        if "" not in own_metas:
            return {"": ChannelMeta.new_empty(self._uid, self.channel)}
        metas = own_metas.copy()
        self_meta = metas[""]

        # 递归获取.
        children_names = self_meta.children
        children = self.sub_channels()
        if len(children) == 0:
            return metas
        for child_name, child in children.items():
            child_runtime = self._importlib.get_channel_runtime(child)
            if not child_runtime or not child_runtime.is_running():
                continue
            if child_name not in children_names:
                children_names.append(child_name)
            descendant_metas = child_runtime.metas()
            for full_path, meta in descendant_metas.items():
                new_full_path = Channel.join_channel_path(child_name, full_path)
                if new_full_path in metas:
                    continue
                metas[new_full_path] = meta

        self_meta.children = children_names
        return metas

    async def refresh_own_metas(self, force: bool) -> None:
        ctx = ChannelCtx(self)
        self._own_metas_cache = await ctx.run(self._generate_own_metas, force)

    @abstractmethod
    async def _generate_own_metas(self, force: bool) -> dict[ChannelFullPath, ChannelMeta]:
        """
        重新生成 meta 数据对象.
        """
        pass

    async def refresh_metas(
        self,
    ) -> None:
        """
        更新当前的 Channel Meta 信息. 递归创建所有子节点的 metas.
        """
        await self._refresh_meta_lock.acquire()
        try:
            if not self._starting or self._closing_event.is_set():
                return
            if not self.is_connected():
                return

            # 生成时添加 ctx.
            await self.refresh_own_metas(force=True)
            # 创建异步的回调.
            await self._refresh_children_metas()
        except asyncio.CancelledError:
            return
        except Exception as exc:
            self.logger.exception("%s refresh self meta failed %s", self.log_prefix, exc)
            # 出现异常后, 刷新一个异常的 meta.
        finally:
            self._refresh_meta_lock.release()
            self.logger.info(
                "%s refreshed meta",
                self.log_prefix,
            )

    async def _refresh_children_metas(self) -> None:
        children = self.sub_channels()
        if len(children) == 0:
            return
        refreshing = []
        for child in children.values():
            runtime = self._importlib.get_channel_runtime(child)
            if not runtime or not runtime.is_running():
                continue
            refreshing.append(runtime.refresh_metas())
        if len(refreshing) > 0:
            done = await asyncio.gather(*refreshing, return_exceptions=True)
            for t in done:
                if isinstance(t, Exception):
                    self.logger.error(f"%s refresh children meta failed %s", self.log_prefix, t)

    # --- status --- #

    def is_running(self) -> bool:
        """
        是否已经启动了. 如果 Runtime 被 close, is_running 为 false.
        """
        return self._started.is_set() and not self._closing_event.is_set()

    def is_available(self) -> bool:
        """
        当前 Channel 对于使用者而言, 是否可用.
        当一个 Runtime 是 running & connected 状态下, 仍然可能会因为种种原因临时被禁用.
        """
        return self.is_running() and self.is_connected() and self._is_available()

    @abstractmethod
    def _is_available(self) -> bool:
        pass

    # --- on task done --- #

    def _parse_task(self, task: CommandTask) -> CommandTask | None:
        if task is None:
            return None
        if task.done():
            return None
        elif not self.is_running():
            self.logger.error(
                "%s failed task %s: not running",
                self.log_prefix,
                task.cid,
            )
            task.fail(CommandErrorCode.NOT_RUNNING.error(f"channel {self.name} not running"))
            return None
        elif not self.is_connected():
            self.logger.info(
                "%s failed task %s: not connected",
                self.log_prefix,
                task.cid,
            )
            task.fail(CommandErrorCode.NOT_CONNECTED.error(f"channel {self.name} not connected"))
            return None
        elif not self.is_available():
            self.logger.info(
                "%s failed task %s: not available",
                self.log_prefix,
                task.cid,
            )
            task.fail(CommandErrorCode.NOT_AVAILABLE.error(f"channel {self.name} not available"))
            return None
        return task

    async def push_task_with_paths(self, paths: ChannelPaths, task: CommandTask) -> None:
        """
        基于路径将任务入栈.
        """
        task = self._parse_task(task)
        if task is None:
            return
        # 设置运行通道记录.
        # 设置 task id 到 pending map 里.
        self._add_task_done_callback(task)
        try:
            if self._defer_clear_mark:
                self._defer_clear_mark = False
                await self.clear_own()
            # 准备入参.
            task.prepare()
            await self._push_task_with_paths(paths, task)
        except Exception as exc:
            self.logger.exception(exc)
            if not task.done():
                task.fail(exc)
            raise exc

    @abstractmethod
    async def _push_task_with_paths(self, paths: ChannelPaths, task: CommandTask) -> None:
        pass

    def on_task_done(self, callback: TaskDoneCallback) -> None:
        # 注册 task 回调.
        self._task_done_callbacks.append(callback)

    def _add_task_done_callback(self, task: CommandTask) -> None:
        if len(self._task_done_callbacks) > 0:
            task.add_done_callback(self._task_done_callback)

    def _task_done_callback(self, task: CommandTask) -> None:
        import inspect

        if not self.is_running():
            return
        if len(self._task_done_callbacks) == 0:
            return
        for callback in self._task_done_callbacks:
            if inspect.iscoroutinefunction(callback):
                # todo: 似乎要考虑线程安全.
                self._loop.create_task(callback(task))
            else:
                # 同步运行.
                self._loop.run_in_executor(None, callback, task)

    async def clear(self) -> None:
        if not self.is_running():
            return
        self._defer_clear_mark = False
        await self.clear_own()
        await self.clear_sub_channels()

    @abstractmethod
    async def clear_own(self) -> None:
        pass

    async def clear_sub_channels(self):
        async def clear_child(_child: Channel):
            child_runtime = await self._importlib.get_or_create_channel_runtime(_child)
            if child_runtime and child_runtime.is_running():
                await child_runtime.clear()

        clear_tasks = []
        children = self.sub_channels()
        for child in children.values():
            clear_tasks.append(clear_child(child))
        if len(clear_tasks) > 0:
            done = await asyncio.gather(*clear_tasks)
            for r in done:
                if isinstance(r, Exception):
                    self._logger.exception("%s clear child failed: %s", self.log_prefix, r)

    def defer_clear(self) -> None:
        self._defer_clear_mark = True

    # --- 开始与结束 --- #

    @contextlib.asynccontextmanager
    async def _container_ctx(self):
        self._container = self.prepare_container(self._container) or self._container
        await self._loop.run_in_executor(None, self._container.bootstrap)
        yield
        self._loop.run_in_executor(None, self._container.shutdown)

    @contextlib.asynccontextmanager
    async def _importlib_ctx(self):
        if self._importlib is None:
            _importlib = self._container.get(BaseImportLib)
            if _importlib is None:
                _importlib = BaseImportLib(self, self._container)
                self.container.set(BaseImportLib, _importlib)
            self._importlib = _importlib
        if self._importlib.main is self:
            await self._importlib.start()
        yield
        if self._importlib.main is self:
            await self._importlib.close()

    @contextlib.asynccontextmanager
    async def _states_ctx(self):
        if self._state_store is None:
            state_store = self.container.get(StateStore)
            if state_store is None:
                state_store = BaseStateStore(owner=self._uid)
            self._state_store = state_store
        self._state_store.register(*self.default_states())
        await self._state_store.start()
        yield
        await self._state_store.close()

    @abstractmethod
    def default_states(self) -> list[State]:
        pass

    @contextlib.asynccontextmanager
    async def _start_and_close_ctx(self):
        ctx = ChannelCtx(self)
        cor = ctx.run(self.on_start_up)
        self.logger.info(
            "%s started",
            self.log_prefix,
        )
        await cor
        yield
        try:
            ctx = ChannelCtx(self)
            on_close_cor = ctx.run(self.on_close)
            await on_close_cor
        except Exception as e:
            self.logger.exception("%s close failed: %s", self.log_prefix, e)

    @abstractmethod
    async def on_close(self) -> None:
        pass

    @contextlib.asynccontextmanager
    async def _running_task_ctx(self):
        ctx = ChannelCtx(self)
        self._running_task = asyncio.create_task(ctx.run(self._execute_running_task))
        yield
        if self._running_task and not self._running_task.done():
            self._running_task.cancel()
            try:
                await self._running_task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                self.logger.exception("%s close running task failed %s", self.log_prefix, e)

    @abstractmethod
    async def on_running(self) -> None:
        pass

    async def _execute_running_task(self) -> None:
        try:
            await self.on_running()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.exception("%s keep_running_task failed: %s", self.log_prefix, e)
        finally:
            self.logger.debug("%s keep_running_task finished", self.log_prefix)

    @contextlib.asynccontextmanager
    async def _main_loop_ctx(self):
        self._main_loop_task = asyncio.create_task(self._main_loop())
        yield
        try:
            await self.clear()
            if self._main_loop_task and not self._main_loop_task.done():
                self._main_loop_task.cancel()
                try:
                    await self._main_loop_task
                except asyncio.CancelledError:
                    pass
            self._main_loop_task = None
        except Exception as e:
            self.logger.exception(e)
            raise

    @abstractmethod
    async def _main_loop(self) -> None:
        pass

    def _async_exit_ctx_funcs(self) -> Iterable[Callable]:
        yield self._container_ctx
        yield self._importlib_ctx
        yield self._states_ctx
        yield self._start_and_close_ctx
        yield self._running_task_ctx
        yield self._main_loop_ctx

    async def start(self):
        """
        启动 Channel Runtime.
        通常用 with statement 或 async exit stack 去启动.
        只会启动当前 channel 自身.
        """
        if self._starting:
            return
        self._starting = True
        self._loop = asyncio.get_running_loop()
        await self._exit_stack.__aenter__()
        for ctx_func in self._async_exit_ctx_funcs():
            await self._exit_stack.enter_async_context(ctx_func())
            self.logger.debug("%s start stack %s entered", self.log_prefix, ctx_func)
        if self.is_connected():
            # 在启动时更新自己的 metas.
            await self.refresh_own_metas(False)
        # 递归启动子节点.
        await self._start_sub_channels()
        self._started.set()
        self.logger.info("%s started", self.log_prefix)
        return self

    async def _start_sub_channels(self) -> None:
        children = self.sub_channels()
        if len(children) == 0:
            return

        async def _start_child(_channel: Channel):
            runtime = await self._importlib.compile_channel(_channel)
            if runtime is not None:
                await runtime.wait_started()

        start_all = []
        for child in children.values():
            start_all.append(_start_child(child))
        # 递归启动.
        done = await asyncio.gather(*start_all, return_exceptions=True)
        for t in done:
            if isinstance(t, Exception):
                self.logger.exception("%s failed to start sub channel %s", self.log_prefix, t)

    async def wait_started(self) -> None:
        if self._closing_event.is_set():
            return
        await self._started.wait()

    async def wait_closed(self) -> None:
        await self._closed_event.wait()

    def close_sync(self) -> None:
        if not self.is_running():
            return
        # 运行关闭逻辑.
        self._loop.create_task(self.close())

    async def close(self):
        """
        关闭当前 runtime. 同时阻塞销毁资源直到结束.
        只会关闭当前 channel 的 runtime.
        """
        if self._closing_event.is_set():
            return
        self._closing_event.set()
        try:
            self.logger.info(
                "%s begin to close",
                self.log_prefix,
            )
            # 停止所有行为.
            await self._exit_stack.aclose()
        finally:
            self._closed_event.set()
            if self._logger:
                self._logger.info(
                    "%s closed",
                    self.log_prefix,
                )
            # 做必要的清空.
            self.destroy()

    def destroy(self) -> None:
        # 防止互相持有.
        self._channel = None
        self._state_store = None
        self._task_done_callbacks.clear()
        self._importlib = None


_TaskId = str
_TaskIdWithPaths = tuple[ChannelPaths, _TaskId]


class AbsChannelTreeRuntime(AbsChannelRuntime, ABC):
    # --- main loop --- #

    def __init__(self, *, channel: CHANNEL, container: IoCContainer | None = None, logger: LoggerItf | None = None):
        super().__init__(
            channel=channel,
            container=container,
            logger=logger,
        )
        self._blocking_action_lock = asyncio.Lock()
        self._pending_task_queue: asyncio.Queue[_TaskIdWithPaths | None] = asyncio.Queue()

        # 运行状态池.
        # 生命周期任务.
        self._lifecycle_task: asyncio.Task | None = None
        # 在队列中阻塞的任务.
        self._pending_tasks: dict[_TaskId, CommandTask] = {}
        # 在执行中的异步任务.
        self._executing_self_tasks: dict[_TaskId, CommandTask] = {}
        # 在执行中的非异步任务.
        self._executing_blocking_task: CommandTask | None = None
        self._idled_event = asyncio.Event()

    @abstractmethod
    def sub_channels(self) -> dict[str, Channel]:
        """
        当前持有的子 Channel.
        """
        pass

    def commands(self, available_only: bool = True) -> dict[ChannelFullPath, dict[str, Command]]:
        commands = self.own_commands(available_only).copy()
        result = {"": commands}
        for name, child in self.sub_channels().items():
            child_runtime = self.importlib.get_channel_runtime(child)
            if child_runtime and child_runtime.is_running():
                child_commands = child_runtime.commands(available_only)
                for further_path, command_map in child_commands.items():
                    new_full_path = Channel.join_channel_path(name, further_path)
                    result[new_full_path] = command_map
        return result

    @abstractmethod
    def get_own_command(self, name: str) -> Optional[Command]:
        pass

    def get_command(self, name: CommandUniqueName) -> Optional[Command]:
        chan, command_name = Command.split_uniquename(name)
        if chan == "":
            return self.get_own_command(command_name)
        runtime = self.importlib.recursively_find_runtime(self, chan)
        if runtime is None:
            return None
        return runtime.get_command(command_name)

    async def wait_idle(self) -> None:
        """
        阻塞等待到闲时.
        """
        if not self.is_running():
            return
        wait_1 = asyncio.create_task(self._idled_event.wait())
        wait_2 = asyncio.create_task(self._closing_event.wait())
        done, pending = await asyncio.wait([wait_1, wait_2], return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()

    # --- lifecycle --- #

    async def idle(self) -> None:
        """
        进入闲时状态.
        闲时状态指当前 Runtime 及其 子 Channel 都没有 CommandTask 在运行的时候.
        """
        if not self.is_running():
            return
        await self._clear_lifecycle_task()
        await self._blocking_action_lock.acquire()
        try:
            await asyncio.sleep(0.0)
            ctx = ChannelCtx(self)
            on_idle_cor = ctx.run(self.on_idle)
            # idle 是一个在生命周期中单独执行的函数.
            task = asyncio.create_task(on_idle_cor)
            self._lifecycle_task = task
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._logger.exception("%s idle task failed %s", self.log_prefix, exc)
            # 不返回.
        finally:
            self._blocking_action_lock.release()
            self.logger.info("%s idling", self.log_prefix)

    @abstractmethod
    async def on_idle(self) -> None:
        """
        进入闲时状态.
        闲时状态指当前 Runtime 及其 子 Channel 都没有 CommandTask 在运行的时候.
        """
        pass

    async def _clear_lifecycle_task(self) -> None:
        """
        终止进行中的生命周期函数.
        """
        # 终止阻塞中的任务.
        self._idled_event.clear()
        await self._blocking_action_lock.acquire()
        try:
            if self._lifecycle_task and not self._lifecycle_task.done():
                self._lifecycle_task.cancel()
                await self._lifecycle_task
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.logger.exception("%s clear lifecycle task failed: %s", self.log_prefix, e)
        finally:
            self._lifecycle_task = None
            self._blocking_action_lock.release()

    async def _wait_children_idled(self) -> None:
        async def wait_child_empty(_child: Channel):
            runtime = await self._importlib.get_or_create_channel_runtime(_child)
            if runtime and runtime.is_running():
                await runtime.wait_idle()
            return

        wait_all = []
        children = self.sub_channels()
        if len(children) > 0:
            for child in children.values():
                wait_all.append(wait_child_empty(child))
            _ = await asyncio.gather(*wait_all)

    def _is_children_idled(self) -> bool:
        children = self.sub_channels()
        if len(children) > 0:
            for child in children.values():
                runtime = self.importlib.get_channel_runtime(child)
                if not runtime or not runtime.is_running():
                    continue
                elif not runtime.is_idle():
                    return False
        return True

    def is_idle(self) -> bool:
        return self.is_running() and self._idled_event.is_set()

    async def _main_loop(self) -> None:
        try:
            # 等待启动再开始.
            await self.wait_started()
            while not self._closing_event.is_set():
                # 确保让出.
                await asyncio.sleep(0.0)
                _pending_queue = self._pending_task_queue
                # 如果队列是空的, 则要看看是否能够启动 idle.
                if _pending_queue.empty() and not self._idled_event.is_set():
                    # 存在执行中的任务, 继续去拉取.
                    if self._executing_blocking_task or len(self._pending_tasks) > 0:
                        continue
                    # 可以执行 idle 了.
                    if self._is_children_idled():
                        # 这种情况下就真的可以 idle 了. 速度应该很快.
                        await self.idle()
                        self._idled_event.set()
                        continue
                # 阻塞等待下一个结果.
                try:
                    item = await asyncio.wait_for(_pending_queue.get(), timeout=0.1)
                except asyncio.TimeoutError:
                    continue

                # 可能拿到了 clear 清空后的毒丸.
                if item is None:
                    self.logger.info("%s receive none from pending task queue", self.log_prefix)
                    continue
                # 拿到新命令后, 就清空生命周期函数.
                paths, task_id = item
                # consume 动作认为是阻塞的, 它会快速执行, 然后去拉下一个 task.
                # 它唯一的目标就是快速消费.
                await self._consume_task(paths, task_id)
        except asyncio.CancelledError as e:
            # 允许被 cancel.
            self.logger.info("%s Cancel consuming pending task loop: %r", self.log_prefix, e)
        finally:
            self._closing_event.set()
            self.logger.info("%s Finished executing loop", self.log_prefix)

    async def _dispatch_children_task(self, paths: ChannelPaths, task: CommandTask) -> None:
        await asyncio.sleep(0)
        if task.done():
            return
        child_name = paths[0]
        # 子节点在路径上不存在.
        child = self.sub_channels().get(child_name)
        if child is None:
            task.fail(CommandErrorCode.NOT_FOUND.error(f"channel `{task.chan}` not found"))
            return

        runtime = await self.importlib.get_or_create_channel_runtime(child)
        if runtime is None:
            task.fail(CommandErrorCode.NOT_FOUND.error(f"channel `{task.chan}` not found"))
            return
        task.send_through.append(child_name)
        # 直接发送给子树.
        further_paths = paths[1:]
        await runtime.push_task_with_paths(further_paths, task)

    async def _consume_task(self, paths: ChannelPaths, task_id: str) -> None:
        """
        尝试运行一个 task. 这个运行周期是全局唯一, 阻塞的.
        """
        if task_id not in self._pending_tasks:
            return None
        consuming = None
        try:
            # consuming 过程中让出一次.
            await asyncio.sleep(0)
            # 阻塞任务存在的时候, 必须等到阻塞任务完成, 或者它被取消.
            # 这里不做优先级检查, 因为入队时做过了.
            if self._executing_blocking_task is not None and not self._executing_blocking_task.done():
                # 等待阻塞任务因为任何原因完成.
                await self._executing_blocking_task.wait(throw=False)
                # 只有 consuming 环节可以控制 executing blocking task
                self._executing_blocking_task = None

            try:
                consuming = self._pending_tasks.pop(task_id)
            except KeyError:
                return None
            if consuming.done():
                consuming = None
                return

            is_self_task = len(paths) == 0
            is_blocking_task = consuming.meta.blocking
            # 检查是不是子节点的任务.
            if not is_self_task:
                # 分配给子节点.
                await self._dispatch_children_task(paths, consuming)
                consuming = None
                return

            if is_blocking_task:
                # 只有 consume 层可以设置 blocking task. 协程安全操作.
                self._executing_blocking_task = consuming
            # 执行自己的任务. 但并不阻塞.
            await self._clear_lifecycle_task()
            await self._execute_self_task_nonblock(consuming)
            consuming = None

        except asyncio.CancelledError:
            raise
        except Exception as e:
            self.logger.exception("%s handle pending task exception: %r", self.log_prefix, e)
        finally:
            # 这个时候, consuming_command_task 正常应该都设置为 None 了.
            if consuming is not None:
                # 不合法的情况, 要检查原因.
                self.logger.error(
                    "%s consuming task not handled: %r",
                    self.log_prefix,
                    consuming,
                )
                consuming.cancel()

    async def _get_task_result(self, task: CommandTask) -> Any:
        # 准备执行.
        await asyncio.sleep(0)
        self.logger.info("%s start task %s", self.log_prefix, task.cid)
        # 初始化函数运行上下文.
        # 使用 dry run 来管理生命周期.
        async with ChannelCtx(self, task).in_ctx():
            # dry run 不会清空 task 状态.
            return await task.dry_run()

    async def _execute_self_task_nonblock(self, task: CommandTask, depth: int = 0) -> asyncio.Task | None:
        """
        阻塞完成一个任务的运行准备.
        这里没有让出逻辑.
        task 虽然被执行了, 但
        """
        # 又要检查一次.
        if task is None or task.done():
            return
        if depth > 10:
            task.fail(CommandErrorCode.INVALID_USAGE.error("stackoverflow"))
            return
        # 确保 task 被加入了状态池.
        await self._add_executing_task(task)
        task.set_state(CommandTaskState.executing)
        # 设置 channel id 来标记执行者.
        task.exec_chan = self.channel.id()
        # 非阻塞函数不能返回 stack
        # 确保 task 被执行了. 但是不要阻塞主链路.
        return self._loop.create_task(self._ensure_task_executed(task, depth, throw=False))

    async def _add_executing_task(self, task: CommandTask) -> None:
        await self._blocking_action_lock.acquire()
        try:
            cid = task.cid
            if cid in self._executing_self_tasks:
                return
            self._executing_self_tasks[cid] = task
            task.add_done_callback(self._on_executing_task_done)
        finally:
            self._blocking_action_lock.release()

    def _on_executing_task_done(self, task: CommandTask) -> None:
        if not self.is_running():
            return
        # 确保垃圾回收.
        cid = task.cid
        try:
            _ = self._executing_self_tasks.pop(cid)
        except KeyError:
            pass

    async def _ensure_task_executed(self, task: CommandTask, depth: int, throw: bool) -> None:
        """
        运行属于自己这个 channel 的 task, 让它进入到 executing group 中.
        """
        # 由于是异步执行的, 再检查一次.
        task = self._parse_task(task)
        if task is None:
            return
        await self._add_executing_task(task)

        get_result_from_task = self._loop.create_task(self._get_task_result(task))
        try:
            origin_task_done = asyncio.create_task(task.wait(throw=False))
            wait_runtime_close = asyncio.create_task(self._closing_event.wait())
            done, pending = await asyncio.wait(
                [origin_task_done, get_result_from_task, wait_runtime_close],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for t in pending:
                t.cancel()
            if origin_task_done in done:
                # origin task 已经运行结束.
                return
            elif wait_runtime_close in done:
                task.fail(CommandErrorCode.NOT_RUNNING.error("runtime closed"))
                return
            result = await get_result_from_task
            # 如果返回值是 stack, 则意味着要循环堆栈.
            if isinstance(result, CommandStackResult):
                # 执行完所有的堆栈. 同时设置真实被执行的任务.
                (await self._fulfill_task_with_its_result_stack(task, result, depth=depth),)
            else:
                # 赋值给原来的 task.
                task.resolve(result)
        except asyncio.CancelledError:
            if not task.done():
                task.cancel()
            if throw:
                raise
        except Exception as e:
            if not task.done():
                task.fail(e)
            self.logger.error("%s task %s failed: %s", self.log_prefix, task.cid, e)
            if throw:
                raise e
        finally:
            if not task.done():
                self.logger.info("%s failed to ensure task done: %s", self.log_prefix, task)
                task.fail(CommandErrorCode.UNKNOWN_ERROR.error(f"execution failed"))
            # 还要确保 get result 这个函数被清空了.
            if task is self._executing_blocking_task:
                self._executing_blocking_task = None
            if not get_result_from_task.done():
                try:
                    get_result_from_task.cancel()
                    # 确保函数执行到了 finally
                    await get_result_from_task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    self.logger.exception(
                        "%s task %s cancel get result failed: %s",
                        self.log_prefix,
                        task,
                        e,
                    )

    async def _fulfill_task_with_its_result_stack(
        self,
        owner: CommandTask,
        stack: CommandStackResult,
        depth: int = 0,
    ) -> None:
        result = stack
        while result is not None:
            get_stack_result = asyncio.create_task(
                self._run_result_stack(owner, result, depth=depth),
            )
            self_done = asyncio.create_task(owner.wait(throw=False))
            done, pending = await asyncio.wait(
                [get_stack_result, self_done],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for t in pending:
                t.cancel()
            result = await get_stack_result

    async def _run_result_stack(
        self,
        owner: CommandTask,
        stack: CommandStackResult,
        depth: int = 0,
    ) -> CommandStackResult | None:
        result = None
        try:
            if not owner.meta.blocking:
                owner.fail(CommandErrorCode.INVALID_USAGE.error(f"invalid command: none blocking task return stack"))
                return
            if depth > 10:
                owner.fail(CommandErrorCode.INVALID_USAGE.error("stackoverflow"))
                return

            self.logger.info(
                "%s Fulfilling task with stack, depth=%s task=%s",
                self.log_prefix,
                depth,
                owner,
            )
            # 遍历生成的新栈.
            async with stack:
                async for sub_task in stack:
                    await asyncio.sleep(0)
                    if owner.done():
                        # 不要继续执行了.
                        break
                    paths = Channel.split_channel_path_to_names(sub_task.chan)
                    if len(paths) > 0:
                        # 发送给子孙了.
                        await self._dispatch_children_task(paths, sub_task)
                        continue

                    # 递归阻塞等待任务被执行.
                    if sub_task.meta.blocking:
                        # 自己的任务仍然要阻塞一下.
                        await self._ensure_task_executed(sub_task, depth=depth + 1, throw=True)
                    else:
                        _ = asyncio.create_task(self._ensure_task_executed(sub_task, depth=depth, throw=False))

                # 完成了所有子节点的调度后, 通知回调函数.
                # !!! 注意: 在这个递归逻辑中, owner 自行决定是否要等待所有的 child task 完成,
                #          如果有异常又是否要取消所有的 child task.
                result = await stack.callback(owner)
                return result
        except asyncio.CancelledError:
            if not owner.done():
                owner.cancel()
            raise
        except Exception as e:
            # 有异常时, 同时取消所有动态生成的 task 对象. 包括发送出去的. 这样就不会有阻塞了.
            self.logger.exception(
                "%s Fulfill task stack failed, task=%s, exception=%s",
                self.log_prefix,
                owner,
                e,
            )
            for child in stack.generated():
                if not child.done():
                    child.fail(e)
            owner.fail(e)
        finally:
            # owner 结束时, 子任务可能并未完成.
            if result is None and not owner.done():
                owner.cancel()

    async def _push_task_with_paths(self, paths: ChannelPaths, task: CommandTask) -> None:
        """
        基于路径将任务入栈.
        入栈是高优的同步任务.
        """
        try:
            # 是自己的, 而且是要立刻执行的任务.
            task = self._parse_task(task)
            if task is None:
                return
            task_id = task.cid
            # set pending
            task.set_state(CommandTaskState.pending.value)
            # 确认是自身的任务, 并且 call soon.
            is_self_task = len(paths) == 0
            is_blocking_task = task.meta.blocking
            priority = task.meta.priority

            # 进入 pending 列表.
            if is_self_task:
                # 清理运行中的 lifecycle task
                await self._clear_lifecycle_task()
                # call soon
                if task.meta.call_soon:
                    if is_blocking_task:
                        # 需要立刻执行, 而且是一个阻塞类的任务, 则会清空所有运行中的任务.
                        # 设置清空等级为最高.
                        priority = None
                    else:
                        # 立刻将它执行, none blocking 任务确认会进入到并行运行.
                        await self._execute_self_task_nonblock(task, depth=0)
                        # 并不阻塞等待结果, 而是立刻返回.
                        return
            # 来一次优先级的 pk.
            if is_blocking_task:
                self._clear_own_task_by_priority(task.chan, priority)
            self._pending_tasks[task_id] = task
            # 普通的任务, 则会被丢入阻塞队列中排队执行.
            _queue = self._pending_task_queue
            # 入栈.
            _queue.put_nowait((paths, task_id))
        except asyncio.QueueFull:
            task.fail(CommandErrorCode.FAILED.error(f"channel queue is full, clear first"))

    def _clear_own_task_by_priority(self, chan: str, priority: int | None):
        """
        根据优先级清空自身的任务.
        如果 priority 为空, 表示最高优先级, 不做比较.
        """

        reason = "interrupted by higher priority command"
        if self._executing_blocking_task is not None and not self._executing_blocking_task.done():
            # < 0 的 task 任何时候都会被取消.
            if self._executing_blocking_task.meta.priority < 0:
                self._executing_blocking_task.cancel(reason)

        # 接下来只有 priory > 0 的才有资格去取消任务.
        if priority is not None and priority <= 0:
            # 误操作, 没有资格做比较.
            return
        if self._executing_blocking_task is not None and not self._executing_blocking_task.done():
            if priority is None or self._executing_blocking_task.meta.priority < priority:
                self._executing_blocking_task.cancel(reason)
        for task in self._pending_tasks.values():
            # 预先清空队列中优先级低于自身的命令.
            if task.chan != chan:
                continue
            if priority is None or (task.meta.blocking and task.meta.priority < priority):
                if not task.done():
                    task.cancel(reason)

    async def clear_own(self) -> None:
        """
        当轨道命令被触发清空时候执行.
        仅仅清空自身的运行中状态.
        """
        if not self._started.is_set() or self._closed_event.is_set():
            return
        await self._blocking_action_lock.acquire()
        try:
            clear_err = CommandErrorCode.CLEARED.error("cleared by runtime")
            if len(self._pending_tasks) > 0:
                pending_tasks = self._pending_tasks.copy()
                self._pending_tasks.clear()
                for task in pending_tasks.values():
                    if not task.done():
                        task.fail(clear_err)
            # 清空存在的 tasks. 避免内存泄漏. 虽然有队列在拉取.
            self._pending_tasks.clear()

            # 并行执行的 task 也需要被清除.
            if len(self._executing_self_tasks) > 0:
                executing_tasks = self._executing_self_tasks.copy()
                self._executing_self_tasks.clear()
                for t in executing_tasks.values():
                    if not t.done():
                        t.fail(clear_err)
        except Exception as e:
            self.logger.exception("%s clear self failed: %s", self.log_prefix, e)
            raise
        finally:
            self._blocking_action_lock.release()
            self.logger.info("%s cleared", self.log_prefix)
